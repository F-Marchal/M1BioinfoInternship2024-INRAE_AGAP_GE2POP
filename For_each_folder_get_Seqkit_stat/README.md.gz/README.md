# Usage
Will execute `seqkit stat` for all subfolder in your current folde. The outpout will be wroted in a new folder named `SEQKIT_STATS`  

# Execution :
`path_to_statsSrc=YourPath`
`bash $path_to_statsSrc`

