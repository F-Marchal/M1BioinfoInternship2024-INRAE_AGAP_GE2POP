#!/usr/bin/env python3
# encoding=utf-8
"""!
@package utilities
@brief Contain a number of function related to file reading and generation of figure using matplotlib.
It's a toolbox for scripts/snp_analyser.py
"""
from . import utilities
