Version 1.1.2 of https://github.com/F-Marchal/SnpHeatMap/tree/v1.1.2

