Tool to exploit result from Read_per_contig.

Split All Bams intoo separated files.

python 3 [File path] [Ouptut dir] [Divider]

The divider will reduce the number of different read number.
With a divider of 10 and a number of read of 113, the result will be 113 // 10 => 11
 
