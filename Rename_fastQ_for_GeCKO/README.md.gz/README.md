Rename FastQ files to make them usable by GeCKO (Only works with our FastQ)

python3 rename.py [YourFolder]

