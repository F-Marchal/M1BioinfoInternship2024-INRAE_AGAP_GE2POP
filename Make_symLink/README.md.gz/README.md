For all items in a folder, generate symlink inside another folder
bash makeSymLink.sh  [Target] [Destination]

For all subfolders in a folder, use makeSymlink.sh to generate symlink in your current folder
bash makeAboveSymLink.sh [Target] [Path to makeSymLink.sh]
