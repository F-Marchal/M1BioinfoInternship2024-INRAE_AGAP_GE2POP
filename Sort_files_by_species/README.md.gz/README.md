Sort FASTQ files by species.

Use python3

python3 sort.py [targeted folder] [1st table] [2nd table]

1st and 2nd tables are inside ../../01_raw_data/02_CORRELATION_TABLE/

