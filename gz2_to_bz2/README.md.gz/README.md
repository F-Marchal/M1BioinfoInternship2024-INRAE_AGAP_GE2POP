Transform .bz2 to gz. The script is quite long to execute since it verify at each steps that there is no corruptions.

sbatch bz2_to_gz.sbatch [Target Folder] [Final Folder]

