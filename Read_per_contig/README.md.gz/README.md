Compare contigs inside a reference with contigs inside a BAM. Will ouptut a .tsv that contain
Bams names / contigs name. Each cells contain the number of time where a contig is found inside a BAM



sbatch [reference] [Folder that contain BAM] [Other samtools options]


Results
